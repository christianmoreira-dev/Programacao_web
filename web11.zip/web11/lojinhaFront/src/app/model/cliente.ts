export class Cliente {
	id?: number;
	nome: string = '';
	email: string = '';
	telefone: string = '';
	senha: string = '';
	ativo?: boolean;
}
