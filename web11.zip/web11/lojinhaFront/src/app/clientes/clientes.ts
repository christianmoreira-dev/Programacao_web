import { Component, OnInit } from '@angular/core';
import { CommonModule } from '@angular/common';
import { Cliente } from '../model/cliente';
import { ClienteService } from './cliente.service';

@Component({
  imports: [CommonModule],
  selector: 'app-clientes',
  templateUrl: './clientes.html',
  styleUrl: './clientes.css'
})
export class Clientes implements OnInit {
  clientes: Cliente[] = [];
  carregando = true;
  erro = '';

  constructor(private readonly clienteService: ClienteService) {}

  ngOnInit(): void {
    this.carregarClientes();
  }

  carregarClientes(): void {
    this.carregando = true;
    this.erro = '';

    this.clienteService.listar().subscribe({
      next: clientes => {
        this.clientes = clientes;
        this.carregando = false;
      },
      error: () => {
        this.erro = 'Nao foi possivel carregar os clientes. Verifique se o backend esta em execucao.';
        this.carregando = false;
      }
    });
  }
}
