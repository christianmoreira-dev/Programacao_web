import { Routes } from '@angular/router';
import { Cadastro } from './cadastro/cadastro';
import { Carrinho } from './carrinho/carrinho';
import { Detalhe } from './detalhe/detalhe';
import { Login } from './login/login';
import { Pedido } from './pedido/pedido';
import { Reenvio } from './reenvio/reenvio';
import { ResultadoBusca } from './resultado-busca/resultado-busca';
import { Vitrine } from './vitrine/vitrine';
import { Clientes } from './clientes/clientes';

export const routes: Routes = [
    {path:"cadastro", component: Cadastro},
    {path:"carrinho", component: Carrinho},
    {path:"detalhe", component: Detalhe},
    {path:"login", component: Login},
    {path:"pedido", component: Pedido},
    {path:"reenvio", component: Reenvio},
    {path:"resultado-busca", component: ResultadoBusca},
    {path:"vitrine", component: Vitrine},
    {path:"clientes", component: Clientes},
    {path:"", component:Vitrine}
];
